# Rencontres, diplomatie et politiques coloniales au Québec

Kristal **autonome**, non réductible au cours qc-pri-us-009.

Contenu : `25 assertions`, `5 relations` et `2 règles/mandats contextualisés`.

Les sources demeurent candidates à revue historique et culturelle. Aucun build v10 ni homologation. Le contrat commun est `urn:kristal:modele-organisation-humaine:modele`.

Pour vérifier : `py -3 tools\kristal.py check .`, puis `build-v9 .` dans ce répertoire (sous Windows).
