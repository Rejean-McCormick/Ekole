# Nations et sociétés autochtones sur le territoire du Québec

Kristal **autonome**, non réductible au cours qc-pri-us-009.

Contenu : `30 assertions`, `13 relations` et `4 règles/mandats contextualisés`.

Les sources demeurent candidates à revue historique et culturelle. Aucun build v10 ni homologation. Le contrat commun est `urn:kristal:modele-organisation-humaine:modele`.

Pour vérifier : `py -3 tools\kristal.py check .`, puis `build-v9 .` dans ce répertoire (sous Windows).


## Extension encyclopédique v4 (2026-10-10)

`canon/domain/encyclopedie-v4.json` apporte 65 fiches contextuelles, 27 références, 20 activités et 57 liens de préalables. Elle constitue une propriété **autonome** du Kristal, indépendante de tous cours. Le graphe v3 historique est inchangé.

Voir `README_ENCYCLOPEDIE_AUTOCHTONES_V4.md` à la racine de l'overlay pour la méthode, la consultation sans IA et les limites. La référence du cours reste épinglée à la v3 tant qu'une évolution n'est pas explicitement validée.
